package com.example.charmainebatulan.groupproject;

public class Content {

    private int id;
    private String topic;
    private int image;
    private String description;
    private String description2;
    private String description3;
    private int codingExample;
    private String youtubeVideo;
    private String videoDescription;


    public Content(int id, String topic, int image, String description, String description2, String description3) {
        this.id = id;
        this.topic = topic;
        this.image = image;
        this.description = description;
        this.description2 = description2;
        this.description3 = description3;
    }

    public Content(int id, String topic, int codingExample) {
        this.id = id;
        this.topic = topic;
        this.codingExample = codingExample;
    }

    public Content(int id, String topic, String youtubeVideo, String videoDescription) {
        this.id = id;
        this.topic = topic;
        this.youtubeVideo = youtubeVideo;
        this.videoDescription = videoDescription;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getTopic() {
        return topic;
    }

    public void setTopic(String topic) {
        this.topic = topic;
    }

    public int getImage() {
        return image;
    }

    public void setImage(int image) {
        this.image = image;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getDescription2() {
        return description2;
    }

    public void setDescription2(String description2) {
        this.description2 = description2;
    }

    public String getDescription3() {
        return description3;
    }

    public void setDescription3(String description3) {
        this.description3 = description3;
    }

    public int getCodingExample() {
        return codingExample;
    }

    public void setCodingExample(int codingExample) {
        this.codingExample = codingExample;
    }

    public String getYoutubeVideo() {
        return youtubeVideo;
    }

    public void setYoutubeVideo(String youtubeVideo) {
        this.youtubeVideo = youtubeVideo;
    }

    public String getVideoDescription() {
        return videoDescription;
    }

    public void setVideoDescription(String videoDescription) {
        this.videoDescription = videoDescription;
    }

    @Override
    public String toString() {
        return topic;


    }
}
