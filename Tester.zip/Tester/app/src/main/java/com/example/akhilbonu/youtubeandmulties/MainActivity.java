package com.example.akhilbonu.youtubeandmulties;


import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;

import com.google.android.youtube.player.YouTubeBaseActivity;
import com.google.android.youtube.player.YouTubeInitializationResult;
import com.google.android.youtube.player.YouTubePlayer;
import com.google.android.youtube.player.YouTubePlayerView;

import java.util.ArrayList;
import java.util.Random;

public class MainActivity extends YouTubeBaseActivity {

    //Declaring all of the widgets
    YouTubePlayerView mYouTubePlayerView;
    TextView qText;
    Button nextBtn;
    Button backBtn;
    Button checkBtn;
    RadioGroup radioGroup;
    RadioButton ans1;
    RadioButton ans2;
    RadioButton ans3;
    RadioButton ans4;
    int currentIndex=0;
    int correctAnsNo=0;


    YouTubePlayer.OnInitializedListener onInitializedListener;
    YouTubePlayer.PlaybackEventListener eventListener;

    private Question[] questionBank = new Question[] {
            new Question(R.string.Question_1,"True","False"),
            new Question(R.string.Question_2,"False","True"),
            new Question(R.string.Question_3,"Correct Answer","Option B","Option C","Option D"),
            new Question(R.string.Question_4,"Correct1","Wrong2","Wrong 3","Wrong 4")
    };
//------------------------------------------------------------------------------------------------
//Creating methods


    //Method to update the question TextView
    public void updateQuestion(){
        int question = questionBank[currentIndex].getqID();
        qText.setText(question);
    }


    //Method to create a String array out of the chosen question object
    public ArrayList<String> getBankStrings(Question[] questionBank, int currentIndex) {
        ArrayList<String> options= new ArrayList<String>();

        if (questionBank[currentIndex].answer == "True" || questionBank[currentIndex].answer == "False") {
            options.add(questionBank[currentIndex].answer);
            options.add(questionBank[currentIndex].incorrect1);
            return options;

        } else {
            options.add(questionBank[currentIndex].answer);
            options.add(questionBank[currentIndex].incorrect1);
            options.add(questionBank[currentIndex].incorrect2);
            options.add(questionBank[currentIndex].incorrect3);
            return options;
        }
    }

    //Method to randomly assign the question answers to the radio buttons
    public void AssignAns(ArrayList<String> options, RadioButton ans1, RadioButton ans2, RadioButton ans3, RadioButton ans4) {
        if (options.size() == 2) {
            ans3.setVisibility(View.INVISIBLE);
            ans4.setVisibility(View.INVISIBLE);

            //Assign the true and false randomly to the first 2 radio buttons
            int randomIndex = Math.abs(new Random().nextInt(2));

            ans1.setText(options.get(randomIndex));
            options.remove(randomIndex);

            ans2.setText(options.get(0));

        } else {
            ans3.setVisibility(View.VISIBLE);
            ans4.setVisibility(View.VISIBLE);

            //Assign the options randomly to the 4 radio buttons
            int randomIndex = Math.abs(new Random().nextInt(4));

            ans1.setText(options.get(randomIndex));
            options.remove(randomIndex);

            randomIndex = Math.abs(new Random().nextInt(3));
            ans2.setText(options.get(randomIndex));
            options.remove(randomIndex);

            randomIndex = Math.abs(new Random().nextInt(2));
            ans3.setText(options.get(randomIndex));
            options.remove(randomIndex);

            ans4.setText(options.get(0));
        }
    }

    public String getCorrectAns(int currentIndex, Question[] questionBank) {
        return questionBank[currentIndex].answer;
    }

    public RadioButton findCorrectBtn(String correct, RadioButton ans1, RadioButton ans2, RadioButton ans3, RadioButton ans4) {

        if(ans1.getText()==correct) return ans1;

        else if (ans2.getText()==correct) return ans2;

        else if (ans3.getText()==correct) return ans3;

        else return ans4;
    }

    public boolean correctChecked(RadioButton correct) {
        return correct.isChecked();
    }

//Aggregate Methods:

    public void checkAns() {
        String correctAns = getCorrectAns(currentIndex,questionBank);
        RadioButton correctBtn = findCorrectBtn(correctAns, ans1,ans2,ans3,ans4);
        boolean result = correctChecked(correctBtn);

        if (result == true) {
            correctAnsNo = correctAnsNo +1;

            qText.setText(String.valueOf(correctAnsNo));

        }
        else qText.setText(String.valueOf(correctAnsNo));
        checkBtn.setVisibility(View.INVISIBLE);
    }


    public void refreshQuestions() {
        updateQuestion();
        ArrayList<String> options = getBankStrings(questionBank, currentIndex);
        AssignAns(options, ans1, ans2,ans3,ans4);
    }

//------------------------------------------------------------------------------------------------

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //Assigning widgets to views in the main activity
        mYouTubePlayerView = findViewById(R.id.youtubePlay);
        qText = findViewById(R.id.qText);
        nextBtn = findViewById(R.id.nextBtn);
        backBtn = findViewById(R.id.backBtn);
        checkBtn = findViewById(R.id.checkBtn);
        radioGroup = findViewById(R.id.radioGroup);
        ans1 = findViewById(R.id.ans1);
        ans2 = findViewById(R.id.ans2);
        ans3 = findViewById(R.id.ans3);
        ans4 = findViewById(R.id.ans4);

        //Launching the YouTube Video
        onInitializedListener = new YouTubePlayer.OnInitializedListener() {
            @Override
            public void onInitializationSuccess(YouTubePlayer.Provider provider, YouTubePlayer youTubePlayer, boolean b) {
                youTubePlayer.loadVideo("0PPKccntohM");
            }

            @Override
            public void onInitializationFailure(YouTubePlayer.Provider provider, YouTubeInitializationResult youTubeInitializationResult) {
            }
        };
        mYouTubePlayerView.initialize(YouTubeConfig.getApiKey(), onInitializedListener);
        refreshQuestions();


        //Listener for when the next button is clicked
        nextBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                currentIndex = currentIndex +1;
                if (currentIndex<4) {
                    checkAns();
                    radioGroup.clearCheck();
                    refreshQuestions();
                    checkBtn.setVisibility(View.VISIBLE);
                }
                else{
                    currentIndex = 3;
                    qText.setText(R.string.End);
                }

            }
        });

        backBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (currentIndex != 0) {
                    currentIndex = currentIndex - 1;
                    checkBtn.setVisibility(View.VISIBLE);
                    radioGroup.clearCheck();

                    refreshQuestions();
                }
            }
        });
        checkBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                checkAns();
            }
        });


    }


}
