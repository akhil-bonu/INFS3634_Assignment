package com.example.charmainebatulan.groupproject;

import java.util.HashMap;

public class LearnContentData {

    // store content data for learn page
    public static HashMap<Integer, Content> content = new HashMap(){{
        put(0, new Content(0, "Superclass and Subclass", R.drawable.inheritance_diagram, "","",""));
        put(1, new Content(1, "Super Keyword", R.drawable.superkeyword, "","",""));
        put(2, new Content(2, "Defining A Subclass", R.drawable.subclass, "","",""));
        put(3, new Content(3, "Overriding Methods", R.drawable.overriding, "","",""));
        put(4, new Content(4, "Overriding vs. Overloading", R.drawable.overloadride, "","",""));
        put(5, new Content(5, "Visbility Modifiers", R.drawable.visibility_modifier, "","",""));

    }};

    // store content data for review - code example page

    // store content data for review - youtube playlist page
    // return the content id
    public static Content getContentById(int id){
        return content.get(id);
    }


}
