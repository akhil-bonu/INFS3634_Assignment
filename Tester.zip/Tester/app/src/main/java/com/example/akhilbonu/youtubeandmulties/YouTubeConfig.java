package com.example.akhilbonu.youtubeandmulties;

public class YouTubeConfig {
    public YouTubeConfig() {
    }
    private static final String API_KEY = "AIzaSyAmc2AbmSIQbiTfO2MI0KaE8-xQ3X7oW24";

    public static String getApiKey() {
        return API_KEY;
    }
}
