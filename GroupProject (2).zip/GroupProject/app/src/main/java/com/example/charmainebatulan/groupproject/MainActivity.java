package com.example.charmainebatulan.groupproject;

import android.content.Intent;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;

public class MainActivity extends AppCompatActivity {

    ImageView learnIV;
    ImageView questionsIV;
    ImageView quizIV;
    private static final String TAG = "MainActivity";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // find view from layout resource file
        learnIV = (ImageView) findViewById(R.id.learnIV);
        questionsIV = (ImageView) findViewById(R.id.questionsIV);
        quizIV = (ImageView) findViewById(R.id.quizIV);


        // rename action bar
        ActionBar actionBar = getSupportActionBar();
        getSupportActionBar().setTitle(R.string.main_activity_name);

        //onClick for learnIV
        learnIV.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.d(TAG, "onClick: imageView clicked");
                Intent intent = new Intent(MainActivity.this, LearnLandingPage.class);
                startActivity(intent);
                Log.d(TAG, "onClick: intent launched");
            }
        });

        //onClick for questionsIV

        //onClick for quizIV






    }
}
