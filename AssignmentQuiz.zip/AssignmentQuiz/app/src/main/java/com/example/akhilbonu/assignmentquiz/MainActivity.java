package com.example.akhilbonu.assignmentquiz;

import android.os.Build;
import android.os.Bundle;
import android.support.annotation.RequiresApi;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;

import com.google.android.youtube.player.YouTubeBaseActivity;
import com.google.android.youtube.player.YouTubeInitializationResult;
import com.google.android.youtube.player.YouTubePlayer;
import com.google.android.youtube.player.YouTubePlayerView;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Random;

public class MainActivity extends YouTubeBaseActivity {
    private static final String TAG = "MainActivity";
    YouTubePlayerView youTubePlayerView;
    YouTubePlayer.OnInitializedListener onInitializedListener;

    ImageView imageView;
    Button nextBtn;
    Button backBtn;
    EditText editText;
    TextView qText;

    //Making in-code checks
    int currentIndex=0;
    int correctAnsNo=0;
    boolean vidStarted; //Boolean to tell if video has started or not

    //Making radio buttons
    RadioGroup radioGroup;
    RadioButton ans1;
    RadioButton ans2;
    RadioButton ans3;
    RadioButton ans4;

    Question[] qBank = new Question[] {
            //NOTE: All the free response answers should be in ALL lowercase
            //PSS: the constructors need to assign the image to the question
            new Question(R.string.Question_1,"True","False", null, null, null, 'T','N'),
            new Question(R.string.Question_2,"False","True", null, null, null, 'T','N'),
            new Question(R.string.Question_3,"Answer3","Wrong1", "Wrong2", "Wrong3", null, 'M','N'),
            new Question(R.string.Question_4,"Answer4","Wrong1", "Wrong2", "Wrong3", null, 'M','N'),
            new Question(R.string.Question_5,"answer5","Wrong1", "Wrong2", "Wrong3", null, 'F','N'),//free
            new Question(R.string.Question_6,"Answer6",null, null, null, null, 'F','N'), //Free
            new Question(R.string.Question_7,"Answer7","True", null, null, R.drawable.test2, 'T','I'),
            new Question(R.string.Question_8,"Answer8","Wrong1", "Wrong2", "Wrong3", R.drawable.test2, 'M','I'),
            new Question(R.string.Question_9,"answer9",null, null, null, R.drawable.test2, 'F','N'), //free
            new Question(R.string.Question_10,"Answer10","Wrong1", "Wrong2", "Wrong3", R.drawable.test2, 'M','I'),
            new Question(R.string.Question_11,"Answer13","True", null, null, null, 'T','Y'),
            new Question(R.string.Question_12,"Answer14","Wrong1", "Wrong2", "Wrong3", null, 'M','Y'),
            new Question(R.string.Question_13,"answer15",null, null, null, null, 'F','Y'), //free
    };

    //OnCreate Method
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        Log.d(TAG, "onCreate: Starting onCreate");
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //Setting widgets to views
        youTubePlayerView = findViewById(R.id.youTubePlayer);
        qText = findViewById(R.id.qText);
        nextBtn = findViewById(R.id.nextBtn);
        backBtn = findViewById(R.id.backBtn);
        radioGroup = findViewById(R.id.radioGroup);
        ans1 = findViewById(R.id.ans1);
        ans2 = findViewById(R.id.ans2);
        ans3 = findViewById(R.id.ans3);
        ans4 = findViewById(R.id.ans4);
        editText = findViewById(R.id.editText);
        imageView = findViewById(R.id.imageView);

       imageView.setVisibility(View.VISIBLE);
        youTubePlayerView.setVisibility(View.INVISIBLE);
        editText.setVisibility(View.INVISIBLE);

        refreshQ();

        nextBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                checkAns(qBank[currentIndex]);
                currentIndex++;
                refreshQ();
            }
        });

        Log.d(TAG, "onCreate: Successfully completed onCreate");
    }
    //End of OnCreate

    public void refreshQ(){
        radioGroup.clearCheck();
        qText.setText(qBank[currentIndex].getqID());//Updating the Question field
        updateExtraTypeVisibilities(qBank[currentIndex]);
        updateQTypeVisibilities(qBank[currentIndex]);
        if (qBank[currentIndex].getqType()!='F') { assignAnswers(qBank[currentIndex]); }


    }


//-------------------------Visibilities-------------------------Visibilities-------------------------Visibilities
    public void updateExtraTypeVisibilities(Question question) {
        if(question.getExtras() == 'Y') {
            youTubePlayerView.setVisibility(View.VISIBLE);
            imageView.setVisibility(View.INVISIBLE);

            //Starting video if it hasn't already been started
            if(!vidStarted) { startVideo(); } else Log.d(TAG, "checkExtra: Video has already started");

        } else if (question.getExtras() == 'I') {
            Log.d(TAG, "updateExtraTypeVisibilities: Trying to change image");
            //Code to set the image to the image based on question.getImageRef
            imageView.setImageResource(question.getImageRef());

            //Set visibilities
            youTubePlayerView.setVisibility(View.INVISIBLE);
            imageView.setVisibility(View.VISIBLE);

        } else if (question.getExtras() == 'N') {
            //Code to set image as placeholder
            imageView.setImageResource(R.drawable.placeholder);

            //Set visibilities
            youTubePlayerView.setVisibility(View.INVISIBLE);
            imageView.setVisibility(View.VISIBLE);
        }
    }

    public void updateQTypeVisibilities(Question question) {
        if (question.getqType() == 'T') {
            Log.d(TAG, "checkType: True/False question");

            ans1.setVisibility(View.VISIBLE);
            ans2.setVisibility(View.VISIBLE);
            ans3.setVisibility(View.INVISIBLE);
            ans4.setVisibility(View.INVISIBLE);
            editText.setVisibility(View.INVISIBLE);


        } else if (question.getqType() == 'M') {
            Log.d(TAG, "checkType: Multiple choice Q");

            ans1.setVisibility(View.VISIBLE);
            ans2.setVisibility(View.VISIBLE);
            ans3.setVisibility(View.VISIBLE);
            ans4.setVisibility(View.VISIBLE);
            editText.setVisibility(View.INVISIBLE);

        } else if (question.getqType() == 'F') {
            Log.d(TAG, "checkType: Free response question");

            ans1.setVisibility(View.INVISIBLE);
            ans2.setVisibility(View.INVISIBLE);
            ans3.setVisibility(View.INVISIBLE);
            ans4.setVisibility(View.INVISIBLE);
            editText.setVisibility(View.VISIBLE);
        }
    }
//-------END------------------Visibilities--------------END-----------Visibilities-------------END


    public void assignAnswers(Question question){
        ArrayList<String> options = new ArrayList<>(Arrays.asList(question.getAnswer(),question.getIncorrect1(),question.getIncorrect2(),question.getIncorrect3()));
        Log.d(TAG, "assignAnswers: Assigning answers for question: " + currentIndex);
        if (options.get(1).equals("True") || options.get(1).equals("False")) {
            ans1.setText(R.string.True);
            ans2.setText(R.string.False);

        } else {

            //Assign the options randomly to the 4 radio buttons
            int randomIndex = Math.abs(new Random().nextInt(4));

            ans1.setText(options.get(randomIndex));
            options.remove(randomIndex);

            randomIndex = Math.abs(new Random().nextInt(3));
            ans2.setText(options.get(randomIndex));
            options.remove(randomIndex);

            randomIndex = Math.abs(new Random().nextInt(2));
            ans3.setText(options.get(randomIndex));
            options.remove(randomIndex);

            ans4.setText(options.get(0));
        }
    }

 //--------------CHECK ANSWER--------------CHECK ANSWER--------------CHECK ANSWER--------------CHECK ANSWER
//Method to check if the user's answer is correct and make updates to the correct answers number
public void checkAns(Question question) {
        String answer = "";
        String correctAns = question.getAnswer();

        if (question.getqType() == 'F') answer = editText.getText().toString().toLowerCase();
        else if (question.getqType()=='T' || question.getqType()=='M')
            answer = findCorrectBtn(correctAns).toString();

        if(answer.equals(correctAns)) {
            correctAnsNo++;
        }
    Log.d(TAG, "Number of correct answers so far: " + correctAnsNo);
}

    //Method to figure out which RadioButton is holding the right answer
    public RadioButton findCorrectBtn(String correct) {
        if(ans1.getText()==correct) { return ans1; }
        else if (ans2.getText()==correct) {return ans2;}
        else if (ans3.getText()==correct) {return ans3;}
        else return ans4;
    }
//---------END-----CHECK ANSWER--------END------CHECK ANSWER-------END-------CHECK ANSWER-------END-------CHECK ANSWER

    //Method to start the youtube video
    public void startVideo() {
        Log.d(TAG, "startVideo: Starting Video");
        onInitializedListener = new YouTubePlayer.OnInitializedListener() {
            @Override
            public void onInitializationSuccess(YouTubePlayer.Provider provider, YouTubePlayer youTubePlayer, boolean b) {
                youTubePlayer.loadVideo("0PPKccntohM");
                Log.d(TAG, "onInitializationSuccess: Successfully started quiz video");
            }

            @Override
            public void onInitializationFailure(YouTubePlayer.Provider provider, YouTubeInitializationResult youTubeInitializationResult) {
                Log.d(TAG, "onInitializationFailure: Failed to start  quiz video");

            }
        };
        youTubePlayerView.initialize(YouTubeConfig.getApiKey(), onInitializedListener);
    }
    //End of method to start the youtube video

}
