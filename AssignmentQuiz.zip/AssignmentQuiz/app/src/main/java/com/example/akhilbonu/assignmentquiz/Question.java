package com.example.akhilbonu.assignmentquiz;

import android.graphics.drawable.Drawable;
import android.util.Log;

public class Question {
    private static final String TAG = "Question";
    private int qID;
    private String answer;
    private String incorrect1;
    private String incorrect2;
    private String incorrect3;
    private Integer imageRef;
    private char qType;
    private char extras;

    //This constructor is when there are 4 option, with 1 being correct
    public Question(int qID, String answer, String incorrect1, String incorrect2, String incorrect3, Integer imageRef, char qType, char extras) {
        Log.d(TAG, "Question: Main constructor called");
        this.qID=qID;
        this.answer=answer;
        this.incorrect1=incorrect1;
        this.incorrect2=incorrect2;
        this.incorrect3=incorrect3;

        //ImageRef will be the reference that can be inserted to change the image in the imageView
        this.imageRef = imageRef;

        //Qtype: True/False, multies, or free response
        this.qType=qType;
        //extras: none, image, or youtubeVid
        this.extras = extras;
    }

    //Getters and Setters


    public int getqID() { return qID; }

    public void setqID(int qID) { this.qID = qID; }

    public String getAnswer() { return answer; }

    public void setAnswer(String answer) {
        this.answer = answer;
    }

    public String getIncorrect1() {
        return incorrect1;
    }

    public void setIncorrect1(String incorrect1) {
        this.incorrect1 = incorrect1;
    }

    public String getIncorrect2() {
        return incorrect2;
    }

    public void setIncorrect2(String incorrect2) {
        this.incorrect2 = incorrect2;
    }

    public String getIncorrect3() {
        return incorrect3;
    }

    public void setIncorrect3(String incorrect3) {
        this.incorrect3 = incorrect3;
    }

    public Integer getImageRef() {
        return imageRef;
    }

    public void setImageRef(Integer imageRef) {
        this.imageRef = imageRef;
    }

    public char getqType() {
        return qType;
    }

    public void setqType(char qType) {
        this.qType = qType;
    }

    public char getExtras() {
        return extras;
    }

    public void setExtras(char extras) {
        this.extras = extras;
    }
}
