package com.example.akhilbonu.assignmentquiz;

/*
TO DO:
check how to add new activity to manifest
check how to add results.xml to manifest if needed
Do intents, remember to sent the ArrayLists over, the intent should only happy when clicking on the
last 'next' after all the questions are done

Should maybe work a back button into the app?

NEED to figure out what all the questions and answers should be
make the images
finalise the youtube video to use

 */
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;

import com.google.android.youtube.player.YouTubeBaseActivity;
import com.google.android.youtube.player.YouTubeInitializationResult;
import com.google.android.youtube.player.YouTubePlayer;
import com.google.android.youtube.player.YouTubePlayerView;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Random;

public class MainActivity extends YouTubeBaseActivity {

    private static final String TAG = "MainActivity";
    YouTubePlayerView youTubePlayerView;
    YouTubePlayer.OnInitializedListener onInitializedListener;

    ImageView imageView;
    Button nextBtn;
    // Button backBtn; ----Delete???
    EditText editText;
    TextView qText;

    //Making in-code checks
    int currentIndex = 0; //Which question the user is up to
    boolean vidStarted; //Boolean to tell if video has started or not
    boolean userAnswer; //Boolean to tell if the user got the specific question right or not

    //Making radio buttons
    RadioGroup radioGroup;
    RadioButton ans1;
    RadioButton ans2;
    RadioButton ans3;
    RadioButton ans4;

    Question[] qBank = new Question[]{
            //NOTE: All the free response answers should be in ALL lowercase
            //PSS: the constructors need to assign the image to the question
            new Question(R.string.Question_1, "True", "False", null, null, null, 'T', 'N'),
            new Question(R.string.Question_2, "False", "True", null, null, null, 'T', 'N'),
            new Question(R.string.Question_3, "Answer3", "Wrong1", "Wrong2", "Wrong3", null, 'M', 'N'),
            new Question(R.string.Question_4, "Answer4", "Wrong1", "Wrong2", "Wrong3", null, 'M', 'N'),
            new Question(R.string.Question_5, "answer5", "Wrong1", "Wrong2", "Wrong3", null, 'F', 'N'),//free
            new Question(R.string.Question_6, "Answer6", null, null, null, null, 'F', 'N'), //Free
            new Question(R.string.Question_7, "Answer7", "True", null, null, R.drawable.test2, 'T', 'I'),
            new Question(R.string.Question_8, "Answer8", "Wrong1", "Wrong2", "Wrong3", R.drawable.test2, 'M', 'I'),
            new Question(R.string.Question_9, "answer9", null, null, null, R.drawable.test2, 'F', 'N'), //free
            new Question(R.string.Question_10, "Answer10", "Wrong1", "Wrong2", "Wrong3", R.drawable.test2, 'M', 'I'),
            new Question(R.string.Question_11, "Answer13", "True", null, null, null, 'T', 'Y'),
            new Question(R.string.Question_12, "Answer14", "Wrong1", "Wrong2", "Wrong3", null, 'M', 'Y'),
            new Question(R.string.Question_13, "answer15", null, null, null, null, 'F', 'Y'), //free
    };
    

    //Arraylists to hold which questions the user got right and wrong. This list gets sent to the results activity via intents
    ArrayList<Question> gotWrong = new ArrayList<>();
    ArrayList<Question> gotRight = new ArrayList<>();

    //OnCreate Method
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        Log.d(TAG, "onCreate: Starting");
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Log.d(TAG, "onCreate: Set content view successfully");

        //Setting widgets to views
        youTubePlayerView = findViewById(R.id.youTubePlayer);
        qText = findViewById(R.id.qText);
        nextBtn = findViewById(R.id.nextBtn);
        radioGroup = findViewById(R.id.radioGroup);
        ans1 = findViewById(R.id.ans1);
        ans2 = findViewById(R.id.ans2);
        ans3 = findViewById(R.id.ans3);
        ans4 = findViewById(R.id.ans4);
        editText = findViewById(R.id.editText);
        imageView = findViewById(R.id.imageView);
        //   backBtn = findViewById(R.id.backBtn);
        imageView.setVisibility(View.VISIBLE);
        youTubePlayerView.setVisibility(View.INVISIBLE);
        editText.setVisibility(View.INVISIBLE);
        Log.d(TAG, "onCreate: All widgets set to views");

        refreshQ();
        Log.d(TAG, "onCreate: First Question displaying");


        /*
        Every time the user clicks next, the program needs to check if the answer is correct, then
        update the necessary values, then go to the next question
         */
        nextBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Log.d(TAG, "onClick for nextBtn: Starting");

                if (currentIndex == (qBank.length - 1)) {
                    Log.d(TAG, "onClick: Finished Quiz");
                    //Code here to load and start intent for results page


                } else if (currentIndex < qBank.length) {
                    Log.d(TAG, "onClick: In 'else if' section");
                    userAnswer = checkAns(qBank[currentIndex]);
                    Log.d(TAG, "onClick: Checked answer successfully");

                    //If the answer is correct, then add it to the gotRight arraylist
                    //the user got wrong to the arraylist of incorrectly answered questions
                    if (userAnswer) {
                        gotRight.add(qBank[currentIndex]);
                        currentIndex++;

                    } else {
                        gotWrong.add(qBank[currentIndex]);
                        currentIndex++;
                    }
                    refreshQ();
                }
                Log.d(TAG, "onClick: Completed");
            }

        });

        Log.d(TAG, "onCreate: Successfully completed onCreate");
    }

    // Method used to refresh the question screen based on the value of the current Index
    public void refreshQ() {
        Log.d(TAG, "refreshQ: Starting for question " + (currentIndex+1));

        //Clear any existing responses
        radioGroup.clearCheck();
        editText.setText(null);
        Log.d(TAG, "refreshQ: Old responses cleared");

        qText.setText(qBank[currentIndex].getqID()); //Updating the Question field
        updateExtraTypeVisibilities(qBank[currentIndex]); //Update the 'extras' section of the screen
        updateQTypeVisibilities(qBank[currentIndex]); //update which response fields are visible
        Log.d(TAG, "refreshQ: Updated all visibilities");

        //if question is not a free choice, then call method to assign the answers to the radio buttons
        if (qBank[currentIndex].getqType() != 'F') {
            assignAnswers(qBank[currentIndex]);
        }
        Log.d(TAG, "refreshQ: Completed successfully for question " + (currentIndex+1));
    }

/*
updateExtraTypeVisibilities and updateQTypeVisibilities are method to change what is viewable on screen
What is viewable depends on the attributes of the question object,
 */

    //Updating what gets displayed on the top half of the screen
    public void updateExtraTypeVisibilities(Question question) {
        Log.d(TAG, "updateExtraTypeVisibilities: Starting");

        //If question uses the youtube video
        if (question.getExtras() == 'Y') {

            //Set visibilities
            youTubePlayerView.setVisibility(View.VISIBLE);
            imageView.setVisibility(View.INVISIBLE);

            //Starting video if it hasn't already been started
            if (!vidStarted) {
                startVideo(); //method to start the youtube video
            } else {
                Log.d(TAG, "checkExtra: Video has already started");
            }

        //If question uses a non-placeholder image type
        } else if (question.getExtras() == 'I') {
            Log.d(TAG, "updateExtraTypeVisibilities: Trying to change image");
            //Code to set the image to the image based on question.getImageRef
            imageView.setImageResource(question.getImageRef());

            //Set visibilities
            youTubePlayerView.setVisibility(View.INVISIBLE);
            imageView.setVisibility(View.VISIBLE);

            //If question doesn't any extras
        } else if (question.getExtras() == 'N') {
            //Set image as placeholder
            imageView.setImageResource(R.drawable.placeholder);

            //Set visibilities
            youTubePlayerView.setVisibility(View.INVISIBLE);
            imageView.setVisibility(View.VISIBLE);
        }
        Log.d(TAG, "updateExtraTypeVisibilities: Successfully completed");
    }

    //updating which response fields are available
    public void updateQTypeVisibilities(Question question) {
        Log.d(TAG, "updateQTypeVisibilities: Starting for question " + (currentIndex+1));

        if (question.getqType() == 'T') {
            Log.d(TAG, "checkType: T question");

            ans1.setVisibility(View.VISIBLE);
            ans2.setVisibility(View.VISIBLE);
            ans3.setVisibility(View.INVISIBLE);
            ans4.setVisibility(View.INVISIBLE);
            editText.setVisibility(View.INVISIBLE);

        } else if (question.getqType() == 'M') {
            Log.d(TAG, "checkType: Multiple choice Q");

            ans1.setVisibility(View.VISIBLE);
            ans2.setVisibility(View.VISIBLE);
            ans3.setVisibility(View.VISIBLE);
            ans4.setVisibility(View.VISIBLE);
            editText.setVisibility(View.INVISIBLE);

        } else if (question.getqType() == 'F') {
            Log.d(TAG, "checkType: Free response question");

            ans1.setVisibility(View.INVISIBLE);
            ans2.setVisibility(View.INVISIBLE);
            ans3.setVisibility(View.INVISIBLE);
            ans4.setVisibility(View.INVISIBLE);
            editText.setVisibility(View.VISIBLE);
        }
        Log.d(TAG, "updateQTypeVisibilities: Successfully completed for question " + (currentIndex+1));
    }


    /*
    Method to RANDOMLY assign the options for each question to the radio buttons
     */
    public void assignAnswers(Question question) {
        Log.d(TAG, "assignAnswers: Assigning answers for question: " + (currentIndex+1));

        //Put the options into an arrayList (which can handle both multies and T/F
        ArrayList<String> options = new ArrayList<>(Arrays.asList(
                question.getAnswer(),
                question.getIncorrect1(),
                question.getIncorrect2(),
                question.getIncorrect3()));

        //If the wrong answer is either true or false, then assign the options normally
        //since there's only 2 options in this case, no need for randomisation
        if (options.get(1).equals("True") || options.get(1).equals("False")) {
            ans1.setText(R.string.True);
            ans2.setText(R.string.False);

        } else {

            //Assign the options randomly to the 4 radio buttons
            int randomIndex = Math.abs(new Random().nextInt(4));

            ans1.setText(options.get(randomIndex));
            options.remove(randomIndex);

            randomIndex = Math.abs(new Random().nextInt(3));
            ans2.setText(options.get(randomIndex));
            options.remove(randomIndex);

            randomIndex = Math.abs(new Random().nextInt(2));
            ans3.setText(options.get(randomIndex));
            options.remove(randomIndex);

            ans4.setText(options.get(0));
        }
        Log.d(TAG, "assignAnswers: Completed successfully for question " + (currentIndex+1));
    }


//Method to check if the user's answer is correct
    public boolean checkAns(Question question) {
        Log.d(TAG, "checkAns: Checking answer to Question" + (currentIndex+1));
        String answer; //String to hold the correct answer
        String correctAns = question.getAnswer();

        /*
          If the question is free choice, extract the answer from the edit text,
          Otherwise call the findCorrectBtn method
         */
        if (question.getqType() == 'F') { answer = editText.getText().toString().toLowerCase(); }
        else answer = findCorrectBtn(correctAns).toString();


        //Send boolean back to caller based on if user's answer was correct or not
        if (answer.equals(correctAns)) {
            Log.d(TAG, "checkAns: Answer to question " + (currentIndex+1)  + "was correct!");
            return true;
        } else {
            Log.d(TAG, "checkAns: Finished Checking");
            return false;
        }
    }

    //Method to figure out which RadioButton is holding the right answer
    public RadioButton findCorrectBtn(String correct) {
        Log.d(TAG, "findCorrectBtn: Starting for question " + (currentIndex+1));
        if (ans1.getText() == correct) {
            return ans1;
        } else if (ans2.getText() == correct) {
            return ans2;
        } else if (ans3.getText() == correct) {
            return ans3;
        } else {
            return ans4;
        }
    }

    //Method to start the youtube video
    public void startVideo() {
        Log.d(TAG, "startVideo: Starting Video");
        onInitializedListener = new YouTubePlayer.OnInitializedListener() {
            @Override
            public void onInitializationSuccess(YouTubePlayer.Provider provider, YouTubePlayer youTubePlayer, boolean b) {
                youTubePlayer.loadVideo("0PPKccntohM");
                Log.d(TAG, "onInitializationSuccess: Successfully started quiz video");
            }

            @Override
            public void onInitializationFailure(YouTubePlayer.Provider provider, YouTubeInitializationResult youTubeInitializationResult) {
                Log.d(TAG, "onInitializationFailure: Failed to start  quiz video");

            }
        };
        youTubePlayerView.initialize(YouTubeConfig.getApiKey(), onInitializedListener);
        Log.d(TAG, "startVideo: Finished");
    }
}