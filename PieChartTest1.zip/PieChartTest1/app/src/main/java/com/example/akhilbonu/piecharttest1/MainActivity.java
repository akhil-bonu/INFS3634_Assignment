package com.example.akhilbonu.piecharttest1;

import android.graphics.Color;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.TextView;

import com.github.mikephil.charting.charts.PieChart;
import com.github.mikephil.charting.data.Entry;
import com.github.mikephil.charting.data.PieData;
import com.github.mikephil.charting.data.PieDataSet;
import com.github.mikephil.charting.data.PieEntry;
import com.github.mikephil.charting.utils.ColorTemplate;

import org.w3c.dom.Text;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    private static String TAG = "MainActivity";

    PieChart pieChart;
    TextView correctText;
    TextView incorrectText;
    TextView resultTextView;

    Button retakeTestBtn;
    Button homeBtn;

    //Need to pick up these 2 arraylists from the intent (passed on from the quiz activity)
    //DELETE the dummy data when that's figured out
    ArrayList<Question> gotWrong = new ArrayList<Question>(){{
        add(new Question(R.string.Question_1,"True","False", null, null, null, 'T','N'));
                add(new Question(R.string.Question_2,"False","True", null, null, null, 'T','N'));
                add(new Question(R.string.Question_3,"Answer3","Wrong1", "Wrong2", "Wrong3", null, 'M','N'));
                add(new Question(R.string.Question_4,"Answer4","Wrong1", "Wrong2", "Wrong3", null, 'M','N'));
                add(new Question(R.string.Question_5,"answer5","Wrong1", "Wrong2", "Wrong3", null, 'F','N'));//free
                add(new Question(R.string.Question_6,"Answer6",null, null, null, null, 'F','N')); //Free
    }};
    ArrayList<Question> gotRight = new ArrayList<Question>(){{
        add(new Question(R.string.Question_11,"Answer13","True", null, null, null, 'T','Y'));
                add(new Question(R.string.Question_12,"Answer14","Wrong1", "Wrong2", "Wrong3", null, 'M','Y'));
                add(new Question(R.string.Question_13,"answer15",null, null, null, null, 'F','Y'));

    }};

    float results[] = {gotRight.size(), gotWrong.size()};
    String xEntries[] = {"Correct", "Incorrect"};

    double result = gotRight.size()/(gotRight.size()+gotWrong.size());

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        Log.d(TAG, "onCreate: Starting OnCreate");
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //Assigning widgets to views
        pieChart = findViewById(R.id.resultChart);
        correctText = findViewById(R.id.correctText);
        incorrectText = findViewById(R.id.incorrectText);
        resultTextView = findViewById(R.id.resultTextView);
        retakeTestBtn = findViewById(R.id.retakeTestBtn);
        homeBtn = findViewById(R.id.homeBtn);
        setChartFeatures();
        displayResultTexts();

    }

    public void setChartFeatures() {
        pieChart.setRotationEnabled(true);
        pieChart.setUsePercentValues(true);
        pieChart.setCenterTextColor(Color.BLACK);
        pieChart.setHoleRadius(25f);
        pieChart.setHoleColor(Color.WHITE);
        pieChart.setTransparentCircleAlpha(0);
        pieChart.setCenterText(calculateMark(result));
        pieChart.setCenterTextSize(25);
        pieChart.setDrawEntryLabels(true);
        pieChart.setEntryLabelTextSize(20);
        pieChart.setDescription(null);

        setChartData();
        }

    public void setChartData() {
        Log.d(TAG, "setupChart: In method");
        List<PieEntry> pieEntryList = new ArrayList<>();

        for (int i=0; i < results.length; i++) {
            pieEntryList.add(new PieEntry(results[i], xEntries[i]));
        }

        PieDataSet dataSet = new PieDataSet(pieEntryList, "");
        dataSet.setColors(ColorTemplate.COLORFUL_COLORS);
        PieData data = new PieData(dataSet);
        pieChart.setData(data);
        Log.d(TAG, "setupChart: Completed method");
        
    }

    //Displaying the TextViews------Displaying the TextViews------Displaying the TextViews------
    public void displayResultTexts() {
        Log.d(TAG, "displayResultTexts: Starting display method");

        String correctTextString = "You got " + gotRight.size() + " correct";
        String incorrectTextString = "You got " + gotWrong.size() + " incorrect";
        correctText.setText(correctTextString);
        incorrectText.setText(incorrectTextString);

        String mark = calculateMark(result);
        String resultText = "Your mark is " + mark;
        resultTextView.setText(resultText);
    }


    public String calculateMark(double result) {
        Log.d(TAG, "calculateMark: In method");
        int result1 = (int) Math.round(result);
        String mark;

        if (result1 <50) mark = "FL";
        else if ((result1 > 49) && (result1 < 65)) { mark = "PS"; }
        else if ((result1 > 64) && (result1 < 75)) {mark = "CR";}
        else if ((result1 > 74) && (result1 < 85)) {mark = "DS";}
        else  mark = "HD";

        Log.d(TAG, "calculateMark: Completed method ");

        return mark;


    }
    //Finished Displaying the TextViews------Finished Displaying the TextViews------ Finished --------
}
