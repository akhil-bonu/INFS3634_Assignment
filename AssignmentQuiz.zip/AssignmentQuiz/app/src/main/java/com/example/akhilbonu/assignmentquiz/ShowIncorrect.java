package com.example.akhilbonu.assignmentquiz;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;

public class ShowIncorrect extends AppCompatActivity {
    private static final String TAG = "MainQuizActivity";
    Button nextBtn;
    Button backBtn;
    TextView qText;
    TextView answerText;
    TextView hintText;
    ImageView imageView;
    int currentIndex =0;



    @Override
    protected void onCreate(final Bundle savedInstanceState) {
        Log.d(TAG, "onCreate: Starting for ShowIncorrect Activity");
        super.onCreate(savedInstanceState);
        setContentView(R.layout.show_incorrect);
        nextBtn = findViewById(R.id.nextBtn);
        backBtn = findViewById(R.id.backBtn);
        qText = findViewById(R.id.qText);
        answerText = findViewById(R.id.answerText);
        hintText = findViewById(R.id.hintText);
        imageView = findViewById(R.id.imageView);



        //Recieve the Question ArrayList from intent
        final ArrayList<Question> gotWrong = (ArrayList<Question>)getIntent().getSerializableExtra("GotWrong");

        //Loading the first incorrectly answered question
        refreshQ(gotWrong.get(currentIndex));

        //Listener for next button
        nextBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Log.d(TAG, "onClick: Starting");

                if (currentIndex == (gotWrong.size()-1)) { //if user tries clicking next on the last incorrectly answered question
                    //Code to go back to results or home page

                    Log.d(TAG, "onClick: Finished all the questions");
                } else {
                    currentIndex++;
                    refreshQ(gotWrong.get(currentIndex));
                    Log.d(TAG, "onClick: Refreshed to question number: " + (currentIndex+1));

                }
                Log.d(TAG, "onClick: Completed");
            }
        });

        //Listener for back button
        backBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Log.d(TAG, "onClick: Starting");
                if (currentIndex == 0) {//If the user tries clicking back when on the first question
                    Log.d(TAG, "onClick: On first wrong question");
                } else{
                    currentIndex--;
                    refreshQ(gotWrong.get(currentIndex));
                    Log.d(TAG, "onClick: Refreshed to question number: " + (currentIndex+1));
                }
                Log.d(TAG, "onClick: Completed");
            }
        });
    }

    //Method to refresh the page to align with the current Index
    public void refreshQ(Question question) {
        Log.d(TAG, "refreshQ: Starting");
        if (question.getExtras() == 'I') {
            imageView.setImageResource(question.getImageRef());
        } else imageView.setImageResource(R.drawable.placeholder);

        String qTextString = "Q: " + (getResources().getString(question.getqID()));
        qText.setText(qTextString);

        String answerTextString = "The correct answer is: " + question.getAnswer();
        answerText.setText(answerTextString);

        String hintString = "Tip: " + (getResources().getString(question.getHint()));
        hintText.setText(hintString);

        Log.d(TAG, "refreshQ: Completed");
        }
    }

