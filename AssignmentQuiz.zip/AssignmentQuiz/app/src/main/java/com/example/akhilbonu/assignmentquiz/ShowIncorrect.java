package com.example.akhilbonu.assignmentquiz;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Arrays;

public class ShowIncorrect extends AppCompatActivity {
    private static final String TAG = "MainActivity";
    Button nextBtn;
    Button backBtn;
    TextView qText;
    TextView answerText;
    TextView hintText;
    ImageView imageView;
    int currentIndex =0;



    @Override
    protected void onCreate(final Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.show_incorrect);
        nextBtn = findViewById(R.id.nextBtn);
        backBtn = findViewById(R.id.backBtn);
        qText = findViewById(R.id.qText);
        answerText = findViewById(R.id.answerText);
        hintText = findViewById(R.id.hintText);
        imageView = findViewById(R.id.imageView);



        //Recieve the Question ArrayList
        final ArrayList<Question> gotWrong = (ArrayList<Question>)getIntent().getSerializableExtra("GotWrong");


        refreshQ(gotWrong.get(currentIndex));
        nextBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (currentIndex == (gotWrong.size()-1)) {
                    //Code to go back to results page should go here
                    Intent intent = new Intent(ShowIncorrect.this, Results.class);
                    startActivity(intent);

                    Log.d(TAG, "onClick: Finished all the question");
                } else {
                    currentIndex++;
                    refreshQ(gotWrong.get(currentIndex));
                    Log.d(TAG, "onClick: Refreshed to " + (currentIndex+1)  + " wrong question");

                }
            }
        });

        backBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (currentIndex == 0) {
                    Log.d(TAG, "onClick: On first wrong question");
                } else{
                    currentIndex--;
                    refreshQ(gotWrong.get(currentIndex));
                    Log.d(TAG, "onClick: Refreshed to " + (currentIndex+1)  + " wrong question");
                }
            }
        });
    }

    public void refreshQ(Question question) {

        qText.setText(question.getqID());
        answerText.setText(question.getAnswer());
        hintText.setText(question.getHint());

        if (question.getExtras() == 'I') {
            imageView.setImageResource(question.getImageRef());
        }
    }
}
