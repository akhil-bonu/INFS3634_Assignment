package com.example.akhilbonu.youtubeandmulties;

public class Question {
    int qID;
    String answer;
    String incorrect1;
    String incorrect2;
    String incorrect3;


    //This constructor is when there is only a true and false option
    public Question(int qID, String answer, String incorrect1) {
        this.qID = qID;
        this.answer = answer;
        this.incorrect1=incorrect1;
    }

    //This constructor is when there are 4 option, with 1 being correct
    public Question(int qID, String answer, String incorrect1, String incorrect2, String incorrect3) {
        this.qID=qID;
        this.answer=answer;
        this.incorrect1=incorrect1;
        this.incorrect2=incorrect2;
        this.incorrect3=incorrect3;
    }

    //Getters and Setters

    public int getqID() {
        return qID;
    }

    public void setqID(int qID) {
        this.qID = qID;
    }

    public String getAnswer() {
        return answer;
    }

    public void setAnswer(String answer) {
        this.answer = answer;
    }

    public String getIncorrect1() {
        return incorrect1;
    }

    public void setIncorrect1(String incorrect1) {
        this.incorrect1 = incorrect1;
    }

    public String getIncorrect2() {
        return incorrect2;
    }

    public void setIncorrect2(String incorrect2) {
        this.incorrect2 = incorrect2;
    }

    public String getIncorrect3() {
        return incorrect3;
    }

    public void setIncorrect3(String incorrect3) {
        this.incorrect3 = incorrect3;
    }
}
